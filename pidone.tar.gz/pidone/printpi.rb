#!/usr/bin/env ruby
require 'bigdecimal'
require 'bigdecimal/math.rb'
include BigMath
puts PI(500).to_s
